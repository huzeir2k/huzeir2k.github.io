import logo from './logo.svg';
import './App.css';
import IndexPage from './pages/IndexPage';

function App() {
  return (
    <div className="App">
      <IndexPage/>
    </div>
  );
}

export default App;
